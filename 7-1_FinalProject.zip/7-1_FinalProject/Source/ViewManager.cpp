///////////////////////////////////////////////////////////////////////////////
// viewmanager.h
// ============
// manage the viewing of 3D objects within the viewport
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "viewmanager.h"

bool UInitialize(int argc, char* argv[], GLFWwindow** window) {
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    *window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);
    if (*window == NULL) {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return false;
    }

    glfwMakeContextCurrent(*window);
    glfwSetFramebufferSizeCallback(*window, UResizeWindow);
    glfwSetCursorPosCallback(*window, UMousePositionCallback);
    glfwSetScrollCallback(*window, UMouseScrollCallback);
    glfwSetMouseButtonCallback(*window, UMouseButtonCallback);
    glfwSetInputMode(*window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    glewExperimental = GL_TRUE;
    if (glewInit() != GLEW_OK) {
        std::cerr << glewGetErrorString(GLEW_OK) << std::endl;
        return false;
    }

    return true;
}

void ProcessInput(GLFWwindow* window, Camera& gCamera, std::vector<GLMesh>& scene) {
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    if (glfwGetKey(window, GLFW_KEY_RIGHT) == GLFW_PRESS)
        glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);

    if (glfwGetKey(window, GLFW_KEY_LEFT) == GLFW_PRESS)
        glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);

    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        gCamera.ProcessKeyboard(FORWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        gCamera.ProcessKeyboard(BACKWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        gCamera.ProcessKeyboard(LEFT, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        gCamera.ProcessKeyboard(RIGHT, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
        gCamera.ProcessKeyboard(UP, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
        gCamera.ProcessKeyboard(DOWN, gDeltaTime);

    static bool isLKeyDown = false;
    if (glfwGetKey(window, GLFW_KEY_LEFT_ALT) == GLFW_PRESS && !gSpotLightOrbit)
        gSpotLightOrbit = true;
    else if (glfwGetKey(window, GLFW_KEY_RIGHT_ALT) == GLFW_PRESS && gSpotLightOrbit)
        gSpotLightOrbit = false;
}

void RenderScene(Camera& gCamera, std::vector<GLMesh>& scene, GLuint& gShaderProgram, GLuint& gLightProgramId) {
    glEnable(GL_DEPTH_TEST);
    glClearColor(0.035f, 0.144f, 0.220f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glm::mat4 view = gCamera.GetViewMatrix();
    glm::mat4 projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);

    for (auto i = 0; i < scene.size(); ++i) {
        auto mesh = scene[i];

        glBindVertexArray(mesh.vao);
        glUseProgram(gShaderProgram);

        GLint modelLocation = glGetUniformLocation(gShaderProgram, "model");
        GLint viewLocation = glGetUniformLocation(gShaderProgram, "view");
        GLint projLocation = glGetUniformLocation(gShaderProgram, "projection");

        glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(mesh.model));
        glUniformMatrix4fv(viewLocation, 1, GL_FALSE, glm::value_ptr(view));
        glUniformMatrix4fv(projLocation, 1, GL_FALSE, glm::value_ptr(projection));

        GLint objectColorLoc = glGetUniformLocation(gShaderProgram, "objectColor");
        GLint lightColorLoc = glGetUniformLocation(gShaderProgram, "lightColor");
        GLint lightPositionLoc = glGetUniformLocation(gShaderProgram, "lightPos");
        GLint keyLightColorLoc = glGetUniformLocation(gShaderProgram, "keyLightColor");
        GLint keyLightPositionLoc = glGetUniformLocation(gShaderProgram, "keyLightPos");
        GLint viewPositionLoc = glGetUniformLocation(gShaderProgram, "viewPosition");

        glUniform3f(objectColorLoc, mesh.p[0], mesh.p[1], mesh.p[2]);
        glUniform3f(lightColorLoc, gSpotLightColor.r, gSpotLightColor.g, gSpotLightColor.b);
        glUniform3f(lightPositionLoc, gSpotLightPosition.x, gSpotLightPosition.y, gSpotLightPosition.z);
        glUniform3f(keyLightColorLoc, gKeyLightColor.r, gKeyLightColor.g, gKeyLightColor.b);
        glUniform3f(keyLightPositionLoc, gKeyLightPosition.x, gKeyLightPosition.y, gKeyLightPosition.z);

        const glm::vec3 cameraPosition = gCamera.Position;
        glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);

        GLint UVScaleLoc = glGetUniformLocation(gShaderProgram, "uvScale");
        glUniform2fv(UVScaleLoc, 1, glm::value_ptr(mesh.gUVScale));

        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, mesh.textureId);

        glDrawArrays(GL_TRIANGLES, 0, mesh.nIndices);
    }

    RenderLight(gLightProgramId, spotLightMesh, gSpotLightPosition, gSpotLightScale, view, projection);
    RenderLight(gLightProgramId, keyLightMesh, gKeyLightPosition, gKeyLightScale, view, projection);

    glBindVertexArray(0);
    glUseProgram(0);
    glfwSwapBuffers(gWindow);
}

void RenderLight(GLuint& gLightProgramId, GLightMesh& lightMesh, glm::vec3& lightPosition, glm::vec3& lightScale, glm::mat4& view, glm::mat4& projection) {
    glUseProgram(gLightProgramId);
    glBindVertexArray(lightMesh.vao);

    glm::mat4 model = glm::translate(lightPosition) * glm::scale(lightScale);

    GLint modelLoc = glGetUniformLocation(gLightProgramId, "model");
    GLint viewLoc = glGetUniformLocation(gLightProgramId, "view");
    GLint projLoc = glGetUniformLocation(gLightProgramId, "projection");

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    glDrawArrays(GL_TRIANGLES, 0, lightMesh.nVertices);
}
